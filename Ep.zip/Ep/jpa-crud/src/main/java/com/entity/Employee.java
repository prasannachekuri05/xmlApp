package com.entity;

public class Employee {

}

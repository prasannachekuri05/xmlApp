package com.servlet;

public class ServletInterfaceDemo extends   {

}

module PreparedStatementExample {
	requires java.sql;
}